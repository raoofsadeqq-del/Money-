package com.example.finance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.data.*
import com.example.finance.domain.toLocalDate
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

private val WEEK = listOf(
    DayOfWeek.SATURDAY, DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
    DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY
)

@Composable
fun CalendarScreen(s: UiState, vm: MainViewModel) {
    val m = s.month
    var sel by remember(m) { mutableStateOf(if (YearMonth.now() == m) LocalDate.now() else m.atDay(1)) }
    val today = LocalDate.now()

    val byDay = s.entries.groupBy { it.dateMillis.toLocalDate() }
    val billsByDay = s.bills.groupBy { it.dueDateMillis.toLocalDate() }
    val debtsByDay = s.debts.groupBy { it.dueDateMillis.toLocalDate() }

    val offset = (m.atDay(1).dayOfWeek.value - 6 + 7) % 7
    val cells: List<LocalDate?> = List(offset) { null } + (1..m.lengthOfMonth()).map { m.atDay(it) }
    val weeks = cells.chunked(7)

    val dayEntries = byDay[sel].orEmpty()
    val exp = dayEntries.filter { it.type == EntryType.EXPENSE && it.category != Category.OBLIGATION }
    val inc = dayEntries.filter { it.type == EntryType.INCOME }
    val obl = dayEntries.filter { it.category == Category.OBLIGATION && it.type == EntryType.EXPENSE }
    val dayBills = billsByDay[sel].orEmpty()
    val dayDebts = debtsByDay[sel].orEmpty()
    val oblTotal = obl.sumOf { it.amount } +
        dayBills.filter { !it.paid }.sumOf { it.amount } +
        dayDebts.filter { !it.paid && !it.owedToMe }.sumOf { it.amount }

    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { MonthHeader(m, vm) }

        item {
            Column {
                Row(Modifier.fillMaxWidth()) {
                    WEEK.forEach { d ->
                        Text(
                            d.getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault()),
                            Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                weeks.forEach { w ->
                    Row(Modifier.fillMaxWidth()) {
                        for (i in 0 until 7) {
                            val d = w.getOrNull(i)
                            val es = if (d != null) byDay[d].orEmpty() else emptyList()
                            val bl = if (d != null) billsByDay[d].orEmpty() else emptyList()
                            val dl = if (d != null) debtsByDay[d].orEmpty() else emptyList()
                            DayCell(
                                d = d,
                                selected = d != null && d == sel,
                                isToday = d != null && d == today,
                                hasIncome = es.any { it.type == EntryType.INCOME },
                                hasExpense = es.any { it.type == EntryType.EXPENSE },
                                hasDueUnpaid = bl.any { !it.paid } || dl.any { !it.paid },
                                hasDuePaid = bl.any { it.paid } || dl.any { it.paid },
                                modifier = Modifier.weight(1f)
                            ) { if (d != null) sel = d }
                        }
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Legend(GREEN, R.string.sec_income)
                Legend(RED, R.string.lg_expense)
                Legend(ORANGE, R.string.unpaid)
                Legend(BLUE, R.string.paid)
            }
        }

        item { HorizontalDivider() }
        item { Text(stringResource(R.string.day_details, sel.toString()), style = MaterialTheme.typography.titleLarge) }

        item { SectionHeader(R.string.sec_expenses, exp.sumOf { it.amount }) }
        if (exp.isEmpty()) item { Text(stringResource(R.string.none), style = MaterialTheme.typography.bodySmall) }
        items(exp) { e -> EntryRow(e) { vm.deleteEntry(e) } }

        item { SectionHeader(R.string.sec_income, inc.sumOf { it.amount }) }
        if (inc.isEmpty()) item { Text(stringResource(R.string.none), style = MaterialTheme.typography.bodySmall) }
        items(inc) { e -> EntryRow(e) { vm.deleteEntry(e) } }

        item { SectionHeader(R.string.sec_obligations, oblTotal) }
        if (obl.isEmpty() && dayBills.isEmpty() && dayDebts.isEmpty()) item { Text(stringResource(R.string.none), style = MaterialTheme.typography.bodySmall) }
        items(obl) { e -> EntryRow(e) { vm.deleteEntry(e) } }
        items(dayBills) { b -> BillCard(b, { vm.payBill(b) }, { vm.deleteBill(b) }) }
        items(dayDebts) { d -> DebtCard(d, { vm.settleDebt(d) }, { vm.deleteDebt(d) }) }
    }
}

@Composable
fun Legend(color: Color, label: Int) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Dot(color)
        Text(stringResource(label), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun DayCell(
    d: LocalDate?, selected: Boolean, isToday: Boolean,
    hasIncome: Boolean, hasExpense: Boolean, hasDueUnpaid: Boolean, hasDuePaid: Boolean,
    modifier: Modifier, onClick: () -> Unit
) {
    Box(modifier.aspectRatio(1f).padding(2.dp)) {
        if (d != null) {
            val shape = RoundedCornerShape(8.dp)
            val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
            val borderMod = if (isToday) Modifier.border(1.dp, MaterialTheme.colorScheme.primary, shape) else Modifier
            Column(
                Modifier.fillMaxSize().clip(shape).background(bg).then(borderMod).clickable { onClick() },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("%d".format(d.dayOfMonth), style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.height(8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (hasIncome) Dot(GREEN)
                    if (hasExpense) Dot(RED)
                    if (hasDueUnpaid) Dot(ORANGE)
                    if (hasDuePaid) Dot(BLUE)
                }
            }
        }
    }
}
