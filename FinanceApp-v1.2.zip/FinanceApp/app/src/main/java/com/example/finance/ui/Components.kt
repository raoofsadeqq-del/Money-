package com.example.finance.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.data.*
import com.example.finance.domain.toLocalDate
import com.example.finance.domain.toMillis
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneOffset

val GREEN = Color(0xFF2E7D32)
val RED = Color(0xFFC62828)
val ORANGE = Color(0xFFEF6C00)
val BLUE = Color(0xFF1E88E5)

@Composable
fun money(v: Double): String = "%,.0f".format(v) + " " + stringResource(R.string.currency)

@Composable
fun Category.label(): String = stringResource(
    when (this) {
        Category.SALARY -> R.string.cat_salary
        Category.OTHER_INCOME -> R.string.cat_other_income
        Category.OBLIGATION -> R.string.cat_obligation
        Category.VARIABLE -> R.string.cat_variable
        Category.SAVING -> R.string.cat_saving
        Category.INVESTMENT -> R.string.cat_investment
    }
)

// يقبل الأرقام العربية والإنجليزية
fun String.toAmount(): Double? {
    val sb = StringBuilder()
    for (c in this.trim()) {
        when {
            c in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
            c in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
            c == '\u066B' -> sb.append('.')
            c == ',' || c == '\u066C' || c == ' ' -> {}
            else -> sb.append(c)
        }
    }
    return sb.toString().toDoubleOrNull()
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(7.dp).background(color, CircleShape))
}

@Composable
fun SectionTitle(@StringRes id: Int) {
    Text(stringResource(id), style = MaterialTheme.typography.titleMedium)
}

@Composable
fun SectionHeader(@StringRes id: Int, total: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(id), style = MaterialTheme.typography.titleMedium)
        Text(money(total), style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
fun MonthHeader(month: YearMonth, vm: MainViewModel) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton({ vm.shift(-1) }) { Text(if (rtl) "›" else "‹", style = MaterialTheme.typography.headlineSmall) }
        Text(month.toString(), style = MaterialTheme.typography.titleLarge)
        TextButton({ vm.shift(1) }) { Text(if (rtl) "‹" else "›", style = MaterialTheme.typography.headlineSmall) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickDialog(initial: LocalDate, onDismiss: () -> Unit, onPick: (LocalDate) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                val ms = state.selectedDateMillis
                if (ms != null) onPick(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())
                onDismiss()
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton({ onDismiss() }) { Text(stringResource(R.string.cancel)) } }
    ) { DatePicker(state = state) }
}

@Composable
fun EntryRow(e: MoneyEntry, onDelete: () -> Unit) {
    val lab = e.category.label()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(e.note.ifBlank { lab })
            Text(lab, style = MaterialTheme.typography.labelSmall)
        }
        Text(money(e.amount), color = if (e.type == EntryType.INCOME) GREEN else RED)
        TextButton({ onDelete() }) { Text("✕") }
    }
}

@Composable
fun BillCard(b: Bill, onPay: () -> Unit, onDelete: () -> Unit) {
    val due = b.dueDateMillis.toLocalDate()
    val overdue = !b.paid && due.isBefore(LocalDate.now())
    val statusColor = if (b.paid) GREEN else if (overdue) RED else ORANGE
    val statusText = stringResource(if (b.paid) R.string.paid else if (overdue) R.string.overdue else R.string.unpaid)
    val monthly = stringResource(R.string.monthly)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(b.title, style = MaterialTheme.typography.titleMedium)
                Text(money(b.amount))
            }
            Text(due.toString() + (if (b.repeatMonthly) " · " + monthly else ""), style = MaterialTheme.typography.bodySmall)
            Text(statusText, color = statusColor, style = MaterialTheme.typography.labelLarge)
            if (b.notes.isNotBlank()) Text(b.notes, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!b.paid) Button({ onPay() }) { Text(stringResource(R.string.mark_paid)) }
                TextButton({ onDelete() }) { Text(stringResource(R.string.delete)) }
            }
        }
    }
}

@Composable
fun DebtCard(d: Debt, onSettle: () -> Unit, onDelete: () -> Unit) {
    val due = d.dueDateMillis.toLocalDate()
    val overdue = !d.paid && due.isBefore(LocalDate.now())
    val statusColor = if (d.paid) GREEN else if (overdue) RED else ORANGE
    val statusText = stringResource(if (d.paid) R.string.paid else if (overdue) R.string.overdue else R.string.unpaid)
    val dir = stringResource(if (d.owedToMe) R.string.debt_owed_to_me else R.string.debt_i_owe)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(d.person, style = MaterialTheme.typography.titleMedium)
                Text(money(d.amount))
            }
            Text(dir + " · " + due.toString(), style = MaterialTheme.typography.bodySmall)
            Text(statusText, color = statusColor, style = MaterialTheme.typography.labelLarge)
            if (d.note.isNotBlank()) Text(d.note, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!d.paid) Button({ onSettle() }) {
                    Text(stringResource(if (d.owedToMe) R.string.mark_collected else R.string.mark_settled))
                }
                TextButton({ onDelete() }) { Text(stringResource(R.string.delete)) }
            }
        }
    }
}

@Composable
fun AddEntryDialog(onDismiss: () -> Unit, onSave: (Double, EntryType, Category, String, Long) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(Category.VARIABLE) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var picking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                val type = if (cat == Category.SALARY || cat == Category.OTHER_INCOME) EntryType.INCOME else EntryType.EXPENSE
                val a = amount.toAmount()
                if (a != null && a > 0) onSave(a, type, cat, note.trim(), date.toMillis())
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton({ onDismiss() }) { Text(stringResource(R.string.cancel)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text(stringResource(R.string.amount)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(note, { note = it }, label = { Text(stringResource(R.string.note)) })
                OutlinedButton({ picking = true }) { Text(stringResource(R.string.entry_date) + ": " + date.toString()) }
                Category.entries.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c.label()) }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        })
    if (picking) DatePickDialog(date, { picking = false }) { date = it }
}

@Composable
fun AddBillDialog(onDismiss: () -> Unit, onSave: (String, Double, Long, Boolean, Int, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var remind by remember { mutableStateOf("3") }
    var repeat by remember { mutableStateOf(true) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var picking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                val a = amount.toAmount()
                if (a != null && a > 0 && title.isNotBlank()) onSave(title.trim(), a, date.toMillis(), repeat, remind.toIntOrNull() ?: 3, notes.trim())
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton({ onDismiss() }) { Text(stringResource(R.string.cancel)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(stringResource(R.string.bill_title)) }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(stringResource(R.string.amount)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedButton({ picking = true }) { Text(stringResource(R.string.due_date) + ": " + date.toString()) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(repeat, { repeat = it })
                    Text(stringResource(R.string.repeat_monthly))
                }
                OutlinedTextField(remind, { remind = it }, label = { Text(stringResource(R.string.remind_days)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(notes, { notes = it }, label = { Text(stringResource(R.string.note)) })
            }
        })
    if (picking) DatePickDialog(date, { picking = false }) { date = it }
}

@Composable
fun AddDebtDialog(onDismiss: () -> Unit, onSave: (String, Double, Long, Boolean, String) -> Unit) {
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var mine by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var picking by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                val a = amount.toAmount()
                if (a != null && a > 0 && person.isNotBlank()) onSave(person.trim(), a, date.toMillis(), mine, note.trim())
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton({ onDismiss() }) { Text(stringResource(R.string.cancel)) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !mine, onClick = { mine = false }, label = { Text(stringResource(R.string.debt_i_owe)) })
                    FilterChip(selected = mine, onClick = { mine = true }, label = { Text(stringResource(R.string.debt_owed_to_me)) })
                }
                OutlinedTextField(person, { person = it }, label = { Text(stringResource(R.string.debt_person)) }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(stringResource(R.string.amount)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedButton({ picking = true }) { Text(stringResource(R.string.due_date) + ": " + date.toString()) }
                OutlinedTextField(note, { note = it }, label = { Text(stringResource(R.string.note)) })
            }
        })
    if (picking) DatePickDialog(date, { picking = false }) { date = it }
}
