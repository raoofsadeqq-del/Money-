package com.example.finance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.finance.R

@Composable
fun DebtsScreen(s: UiState, vm: MainViewModel) {
    val unpaid = s.debts.filter { !it.paid }
    val paid = s.debts.filter { it.paid }.sortedByDescending { it.dueDateMillis }
    val iOwe = unpaid.filter { !it.owedToMe }.sumOf { it.amount }
    val owedToMe = unpaid.filter { it.owedToMe }.sumOf { it.amount }
    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.tab_debts), style = MaterialTheme.typography.headlineSmall) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.total_i_owe) + ": " + money(iOwe))
                    Text(stringResource(R.string.total_owed_to_me) + ": " + money(owedToMe))
                }
            }
        }
        item { SectionTitle(R.string.unpaid) }
        if (unpaid.isEmpty()) item { Text(stringResource(R.string.none)) }
        items(unpaid) { d -> DebtCard(d, { vm.settleDebt(d) }, { vm.deleteDebt(d) }) }
        item { SectionTitle(R.string.paid) }
        if (paid.isEmpty()) item { Text(stringResource(R.string.none)) }
        items(paid) { d -> DebtCard(d, { vm.settleDebt(d) }, { vm.deleteDebt(d) }) }
    }
}
