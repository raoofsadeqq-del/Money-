package com.example.finance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.finance.R

@Composable
fun BillsScreen(s: UiState, vm: MainViewModel) {
    val unpaid = s.bills.filter { !it.paid }
    val paid = s.bills.filter { it.paid }.sortedByDescending { it.dueDateMillis }
    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(stringResource(R.string.tab_bills), style = MaterialTheme.typography.headlineSmall) }
        item { Text(stringResource(R.string.total_unpaid) + ": " + money(unpaid.sumOf { it.amount }), style = MaterialTheme.typography.titleMedium) }
        item { SectionTitle(R.string.unpaid) }
        if (unpaid.isEmpty()) item { Text(stringResource(R.string.none)) }
        items(unpaid) { b -> BillCard(b, { vm.payBill(b) }, { vm.deleteBill(b) }) }
        item { SectionTitle(R.string.paid) }
        if (paid.isEmpty()) item { Text(stringResource(R.string.none)) }
        items(paid) { b -> BillCard(b, { vm.payBill(b) }, { vm.deleteBill(b) }) }
    }
}
