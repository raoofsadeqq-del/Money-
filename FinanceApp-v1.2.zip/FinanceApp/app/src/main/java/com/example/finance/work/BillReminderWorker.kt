package com.example.finance.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.example.finance.R
import com.example.finance.data.AppDatabase
import com.example.finance.domain.toLocalDate
import java.util.concurrent.TimeUnit

class BillReminderWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    private fun build(title: String, text: String): Notification =
        NotificationCompat.Builder(applicationContext, "bills")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).build()

    override suspend fun doWork(): Result {
        val dao = AppDatabase.get(applicationContext).dao()
        val now = System.currentTimeMillis()
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bills", applicationContext.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_HIGH)
        )
        dao.billsDueBefore(now + TimeUnit.DAYS.toMillis(30)).forEach { b ->
            val from = b.dueDateMillis - TimeUnit.DAYS.toMillis(b.remindDaysBefore.toLong())
            if (now >= from) {
                val text = applicationContext.getString(R.string.notif_text, "%,.0f".format(b.amount), b.dueDateMillis.toLocalDate().toString())
                nm.notify(b.id.toInt(), build(b.title, text))
            }
        }
        dao.debtsDueBefore(now + TimeUnit.DAYS.toMillis(3)).forEach { d ->
            val text = applicationContext.getString(R.string.notif_text, "%,.0f".format(d.amount), d.dueDateMillis.toLocalDate().toString())
            nm.notify(1_000_000 + d.id.toInt(), build(d.person, text))
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) = WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "bill_reminders", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<BillReminderWorker>(1, TimeUnit.DAYS).build())
    }
}
