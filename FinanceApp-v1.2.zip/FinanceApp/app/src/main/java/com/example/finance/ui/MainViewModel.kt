package com.example.finance.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.finance.data.*
import com.example.finance.domain.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.ZoneId

data class UiState(
    val month: YearMonth = YearMonth.now(),
    val entries: List<MoneyEntry> = emptyList(),
    val summary: Summary = Summary(0.0, 0.0, 0.0, emptyMap()),
    val insights: List<Insight> = emptyList(),
    val bills: List<Bill> = emptyList(),
    val debts: List<Debt> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val month = MutableStateFlow(YearMonth.now())

    private fun start(m: YearMonth) = m.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    private fun end(m: YearMonth) = m.plusMonths(1).atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1

    val state: StateFlow<UiState> = month.flatMapLatest { m ->
        combine(
            dao.between(start(m), end(m)),
            dao.between(start(m.minusMonths(1)), end(m.minusMonths(1))),
            dao.allBills(),
            dao.allDebts()
        ) { cur, prev, bills, debts ->
            UiState(m, cur, InsightsEngine.summarize(cur), InsightsEngine.analyze(cur, prev), bills, debts)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    fun shift(delta: Long) { month.value = month.value.plusMonths(delta) }

    fun add(amount: Double, type: EntryType, cat: Category, note: String, dateMillis: Long) = viewModelScope.launch {
        dao.add(MoneyEntry(amount = amount, type = type, category = cat, note = note, dateMillis = dateMillis))
    }
    fun deleteEntry(e: MoneyEntry) = viewModelScope.launch { dao.delete(e) }

    fun addBill(title: String, amount: Double, due: Long, repeat: Boolean, remindDays: Int, notes: String) = viewModelScope.launch {
        dao.addBill(Bill(title = title, amount = amount, dueDateMillis = due, repeatMonthly = repeat, remindDaysBefore = remindDays, notes = notes))
    }
    // تسجيل الدفع: يصبح مدفوعًا + يُسجَّل كمصروف التزام + ينشأ فاتورة الشهر القادم إن كانت شهرية
    fun payBill(b: Bill) = viewModelScope.launch {
        dao.updateBill(b.copy(paid = true))
        dao.add(MoneyEntry(amount = b.amount, type = EntryType.EXPENSE, category = Category.OBLIGATION, note = b.title, dateMillis = System.currentTimeMillis()))
        if (b.repeatMonthly) {
            val next = b.dueDateMillis.toLocalDate().plusMonths(1).toMillis()
            dao.addBill(b.copy(id = 0, dueDateMillis = next, paid = false))
        }
    }
    fun deleteBill(b: Bill) = viewModelScope.launch { dao.deleteBill(b) }

    fun addDebt(person: String, amount: Double, due: Long, owedToMe: Boolean, note: String) = viewModelScope.launch {
        dao.addDebt(Debt(person = person, amount = amount, dueDateMillis = due, owedToMe = owedToMe, note = note))
    }
    // سداد دين عليّ = مصروف التزام، تحصيل دين لي = دخل
    fun settleDebt(d: Debt) = viewModelScope.launch {
        dao.updateDebt(d.copy(paid = true))
        dao.add(MoneyEntry(
            amount = d.amount,
            type = if (d.owedToMe) EntryType.INCOME else EntryType.EXPENSE,
            category = if (d.owedToMe) Category.OTHER_INCOME else Category.OBLIGATION,
            note = d.person, dateMillis = System.currentTimeMillis()))
    }
    fun deleteDebt(d: Debt) = viewModelScope.launch { dao.deleteDebt(d) }
}
