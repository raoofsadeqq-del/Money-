package com.example.finance.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.data.*
import com.example.finance.domain.Insight
import com.example.finance.domain.toLocalDate

private val chartColors = listOf(
    Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00),
    Color(0xFF8E24AA), Color(0xFF00897B), Color(0xFFD81B60)
)

@Composable
fun Dashboard(s: UiState, vm: MainViewModel) {
    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { MonthHeader(s.month, vm) }
        item { SummaryCard(s) }
        item { CategoryChart(s.summary.byCategory) }
        item { Text(stringResource(R.string.insights), style = MaterialTheme.typography.titleMedium) }
        items(s.insights) { InsightCard(it) }
        item { Text(stringResource(R.string.upcoming_bills), style = MaterialTheme.typography.titleMedium) }
        items(s.bills.filter { !it.paid }.take(5)) { b ->
            Text(b.title + " — " + money(b.amount) + " — " + b.dueDateMillis.toLocalDate().toString())
        }
    }
}

@Composable
fun SummaryCard(s: UiState) = Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(stringResource(R.string.income) + ": " + money(s.summary.income))
        Text(stringResource(R.string.spent) + ": " + money(s.summary.spent))
        Text(stringResource(R.string.saved) + ": " + money(s.summary.saved))
        Text(stringResource(R.string.net) + ": " + money(s.summary.net), style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun CategoryChart(data: Map<Category, Double>) {
    if (data.isEmpty()) return
    val max = (data.values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(Modifier.fillMaxWidth().height(140.dp)) {
            val w = size.width / (data.size * 2)
            data.entries.forEachIndexed { i, e ->
                val h = (e.value / max).toFloat() * size.height
                drawRect(chartColors[i % chartColors.size], Offset(i * 2 * w + w / 2, size.height - h), Size(w, h))
            }
        }
        data.entries.forEachIndexed { i, e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp)) { Dot(chartColors[i % chartColors.size]) }
                Spacer(Modifier.width(8.dp))
                Text(e.key.label(), Modifier.weight(1f))
                Text(money(e.value))
            }
        }
    }
}

@Composable
fun InsightCard(i: Insight) {
    val msg = when (i) {
        is Insight.LowSavings -> stringResource(R.string.ins_low_savings, i.ratePct)
        is Insight.Overspending -> stringResource(R.string.ins_overspend, "%,.0f".format(i.gap))
        is Insight.VariableSpike -> stringResource(R.string.ins_variable, i.pct)
        is Insight.HeavyObligations -> stringResource(R.string.ins_obligations, i.pct)
        Insight.OnTrack -> stringResource(R.string.ins_ok)
    }
    Card(Modifier.fillMaxWidth()) { Text(msg, Modifier.padding(12.dp)) }
}
