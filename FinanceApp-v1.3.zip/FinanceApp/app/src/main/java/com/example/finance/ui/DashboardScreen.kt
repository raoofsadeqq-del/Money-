package com.example.finance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.domain.*
import java.time.LocalDate

@Composable
fun Dashboard(s: UiState, vm: MainViewModel) {
    val m = s.month
    val range = DateSpan(m.atDay(1), m.atEndOfMonth())
    val pm = m.minusMonths(1)
    val prevRange = DateSpan(pm.atDay(1), pm.atEndOfMonth())
    val rep = remember(s.all, s.bills, s.debts, m) {
        buildReport(s.all, range, prevRange, s.bills, s.debts, LocalDate.now())
    }
    var manage by remember { mutableStateOf(false) }

    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.app_version), style = MaterialTheme.typography.labelSmall) }
        item { MonthHeader(m, vm) }
        item { TotalsCard(rep.totals, rep.prev) }
        item { BucketChart(rep.totals) }
        item { SectionTitle(R.string.sec_expenses) }
        item { AccountBreakdown(rep.expenseByAccount, rep.totals.expense) }
        item { OutlinedButton({ manage = true }) { Text(stringResource(R.string.manage_accounts)) } }
        item { SectionTitle(R.string.advice) }
        items(rep.tips.take(4)) { AdviceCard(it) }
        item { SectionTitle(R.string.upcoming_bills) }
        items(s.bills.filter { !it.paid }.take(5)) { b ->
            Text(b.title + " — " + money(b.amount) + " — " + b.dueDateMillis.toLocalDate().toString())
        }
    }

    if (manage) ManageAccountsDialog(
        s.accounts,
        { manage = false },
        { n, c -> vm.addAccount(n, c) },
        { a -> vm.deleteAccount(a) }
    )
}
