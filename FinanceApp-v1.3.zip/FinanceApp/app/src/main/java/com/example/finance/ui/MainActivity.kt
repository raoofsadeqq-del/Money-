package com.example.finance.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.finance.R
import com.example.finance.work.BillReminderWorker

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BillReminderWorker.schedule(this)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { AppRoot(vm) } }
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val s by vm.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val tabs = listOf(
        R.string.tab_home to "🏠",
        R.string.tab_calendar to "📅",
        R.string.tab_reports to "📊",
        R.string.tab_bills to "🧾",
        R.string.tab_debts to "🤝"
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(t.second) },
                        label = { Text(stringResource(t.first)) }
                    )
                }
            }
        },
        floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> Dashboard(s, vm)
                1 -> CalendarScreen(s, vm)
                2 -> ReportsScreen(s)
                3 -> BillsScreen(s, vm)
                else -> DebtsScreen(s, vm)
            }
        }
    }
    if (showAdd) {
        val close = { showAdd = false }
        when (tab) {
            3 -> AddBillDialog(close) { t, a, d, r, rd, n -> vm.addBill(t, a, d, r, rd, n); close() }
            4 -> AddDebtDialog(close) { p, a, d, mine, n -> vm.addDebt(p, a, d, mine, n); close() }
            else -> AddEntryDialog(s.accounts, { n, c -> vm.addAccount(n, c) }, close) { a, ty, c, n, d, acc ->
                vm.add(a, ty, c, n, d, acc)
                close()
            }
        }
    }
}
