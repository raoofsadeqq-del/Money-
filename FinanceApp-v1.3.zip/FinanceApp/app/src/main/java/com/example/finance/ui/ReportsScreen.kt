package com.example.finance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.domain.*
import java.time.LocalDate
import java.time.YearMonth

enum class RMode { DAY, WEEK, MONTH, PERIOD }

private fun modeLabel(m: RMode): Int = when (m) {
    RMode.DAY -> R.string.rep_day
    RMode.WEEK -> R.string.rep_week
    RMode.MONTH -> R.string.rep_month
    RMode.PERIOD -> R.string.rep_period
}

@Composable
fun ReportsScreen(s: UiState) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    var mode by remember { mutableStateOf(RMode.DAY) }
    var anchor by remember { mutableStateOf(LocalDate.now()) }
    var from by remember { mutableStateOf(LocalDate.now().minusDays(6)) }
    var to by remember { mutableStateOf(LocalDate.now()) }
    var picking by remember { mutableIntStateOf(0) }

    val range: DateSpan = when (mode) {
        RMode.DAY -> DateSpan(anchor, anchor)
        RMode.WEEK -> {
            // الأسبوع يبدأ من السبت
            val start = anchor.minusDays(((anchor.dayOfWeek.value - 6 + 7) % 7).toLong())
            DateSpan(start, start.plusDays(6))
        }
        RMode.MONTH -> {
            val ym = YearMonth.from(anchor)
            DateSpan(ym.atDay(1), ym.atEndOfMonth())
        }
        RMode.PERIOD -> if (to.isBefore(from)) DateSpan(to, from) else DateSpan(from, to)
    }
    val prevRange: DateSpan = when (mode) {
        RMode.MONTH -> {
            val ym = YearMonth.from(anchor).minusMonths(1)
            DateSpan(ym.atDay(1), ym.atEndOfMonth())
        }
        else -> range.previous()
    }
    val rep = remember(s.all, s.bills, s.debts, range, prevRange) {
        buildReport(s.all, range, prevRange, s.bills, s.debts, LocalDate.now())
    }
    val title = if (range.from == range.to) range.from.toString() else range.from.toString() + " → " + range.to.toString()

    fun shift(dir: Int) {
        anchor = when (mode) {
            RMode.DAY -> anchor.plusDays(dir.toLong())
            RMode.WEEK -> anchor.plusWeeks(dir.toLong())
            RMode.MONTH -> anchor.plusMonths(dir.toLong())
            RMode.PERIOD -> anchor
        }
    }

    LazyColumn(Modifier.padding(16.dp), contentPadding = PaddingValues(bottom = 80.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.tab_reports), style = MaterialTheme.typography.headlineSmall) }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RMode.entries.forEach { md ->
                    FilterChip(
                        selected = mode == md,
                        onClick = { mode = md },
                        label = { Text(stringResource(modeLabel(md))) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            if (mode == RMode.PERIOD) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ picking = 2 }, Modifier.weight(1f)) { Text(stringResource(R.string.rep_from) + " " + from.toString()) }
                    OutlinedButton({ picking = 3 }, Modifier.weight(1f)) { Text(stringResource(R.string.rep_to) + " " + to.toString()) }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ shift(-1) }) { Text(if (rtl) "›" else "‹", style = MaterialTheme.typography.headlineSmall) }
                    TextButton({ picking = 1 }) { Text(title) }
                    TextButton({ shift(1) }) { Text(if (rtl) "‹" else "›", style = MaterialTheme.typography.headlineSmall) }
                }
            }
        }

        item { TotalsCard(rep.totals, rep.prev) }

        item { SectionTitle(R.string.advice) }
        items(rep.tips) { AdviceCard(it) }

        item { SectionTitle(R.string.rep_accounts_exp) }
        item { AccountBreakdown(rep.expenseByAccount, rep.totals.expense) }

        if (rep.obligationByAccount.isNotEmpty()) {
            item { SectionTitle(R.string.rep_accounts_obl) }
            item { AccountBreakdown(rep.obligationByAccount, rep.totals.obligation) }
        }

        if (mode != RMode.DAY) {
            item { SectionTitle(R.string.rep_daily) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Legend(GREEN, R.string.sec_income)
                    Legend(RED, R.string.sec_expenses)
                    Legend(ORANGE, R.string.sec_obl)
                    Legend(BLUE, R.string.sec_saving)
                }
            }
            val days = rep.daily.filter { it.second.hasData }
            if (days.isEmpty()) item { Text(stringResource(R.string.none), style = MaterialTheme.typography.bodySmall) }
            items(days) { p -> DailyRow(p.first, p.second) }
        }
    }

    if (picking != 0) {
        val init = when (picking) {
            1 -> anchor
            2 -> from
            else -> to
        }
        DatePickDialog(init, { picking = 0 }) { d ->
            if (picking == 1) {
                anchor = d
            } else if (picking == 2) {
                from = d
            } else {
                to = d
            }
        }
    }
}
