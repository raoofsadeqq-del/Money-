package com.example.finance.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

enum class EntryType { INCOME, EXPENSE }
enum class Category { SALARY, OTHER_INCOME, OBLIGATION, VARIABLE, SAVING, INVESTMENT }

@Entity(tableName = "entries", indices = [Index("dateMillis")])
data class MoneyEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val type: EntryType,
    val category: Category,
    val note: String = "",
    val dateMillis: Long,
    val currency: String = "YER",
    val account: String? = null
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val dueDateMillis: Long,
    val repeatMonthly: Boolean = true,
    val remindDaysBefore: Int = 3,
    val paid: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val person: String,
    val amount: Double,
    val dueDateMillis: Long,
    val owedToMe: Boolean = false,
    val paid: Boolean = false,
    val note: String = ""
)

@Entity(tableName = "accounts")
data class SubAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parent: Category
)

@Dao
interface FinanceDao {
    @Insert suspend fun add(e: MoneyEntry)
    @Delete suspend fun delete(e: MoneyEntry)
    @Query("SELECT * FROM entries ORDER BY dateMillis DESC") fun allEntries(): Flow<List<MoneyEntry>>

    @Insert suspend fun addBill(b: Bill)
    @Update suspend fun updateBill(b: Bill)
    @Delete suspend fun deleteBill(b: Bill)
    @Query("SELECT * FROM bills ORDER BY dueDateMillis") fun allBills(): Flow<List<Bill>>
    @Query("SELECT * FROM bills WHERE paid = 0 AND dueDateMillis <= :limit") suspend fun billsDueBefore(limit: Long): List<Bill>

    @Insert suspend fun addDebt(d: Debt)
    @Update suspend fun updateDebt(d: Debt)
    @Delete suspend fun deleteDebt(d: Debt)
    @Query("SELECT * FROM debts ORDER BY dueDateMillis") fun allDebts(): Flow<List<Debt>>
    @Query("SELECT * FROM debts WHERE paid = 0 AND owedToMe = 0 AND dueDateMillis <= :limit") suspend fun debtsDueBefore(limit: Long): List<Debt>

    @Insert suspend fun addAccount(a: SubAccount)
    @Delete suspend fun deleteAccount(a: SubAccount)
    @Query("SELECT * FROM accounts ORDER BY id") fun allAccounts(): Flow<List<SubAccount>>
    @Query("SELECT COUNT(*) FROM accounts") suspend fun accountCount(): Int
    @Query("SELECT COUNT(*) FROM accounts WHERE name = :n AND parent = :p") suspend fun accountExists(n: String, p: Category): Int
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `debts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `person` TEXT NOT NULL, `amount` REAL NOT NULL, `dueDateMillis` INTEGER NOT NULL, `owedToMe` INTEGER NOT NULL, `paid` INTEGER NOT NULL, `note` TEXT NOT NULL)")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `entries` ADD COLUMN `account` TEXT")
        db.execSQL("CREATE TABLE IF NOT EXISTS `accounts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `parent` TEXT NOT NULL)")
    }
}

@Database(entities = [MoneyEntry::class, Bill::class, Debt::class, SubAccount::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: android.content.Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "finance.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { inst = it }
        }
    }
}
