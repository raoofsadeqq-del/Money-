package com.example.finance.domain

import com.example.finance.data.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class Bucket { INCOME, EXPENSE, OBLIGATION, SAVING }

fun Category.bucket(): Bucket = when (this) {
    Category.SALARY, Category.OTHER_INCOME -> Bucket.INCOME
    Category.VARIABLE -> Bucket.EXPENSE
    Category.OBLIGATION -> Bucket.OBLIGATION
    Category.SAVING, Category.INVESTMENT -> Bucket.SAVING
}

data class Totals(
    val income: Double = 0.0,
    val expense: Double = 0.0,
    val obligation: Double = 0.0,
    val saving: Double = 0.0
) {
    val outflow: Double get() = expense + obligation + saving
    val net: Double get() = income - outflow
    val savingRate: Double get() = if (income > 0) saving / income else 0.0
    val hasData: Boolean get() = income + expense + obligation + saving > 0
}

fun totalsOf(list: List<MoneyEntry>): Totals {
    var i = 0.0
    var e = 0.0
    var o = 0.0
    var s = 0.0
    for (x in list) {
        when (x.category.bucket()) {
            Bucket.INCOME -> { i += x.amount }
            Bucket.EXPENSE -> { e += x.amount }
            Bucket.OBLIGATION -> { o += x.amount }
            Bucket.SAVING -> { s += x.amount }
        }
    }
    return Totals(i, e, o, s)
}

data class DateSpan(val from: LocalDate, val to: LocalDate) {
    val days: Int get() = ChronoUnit.DAYS.between(from, to).toInt() + 1
    fun previous(): DateSpan = DateSpan(from.minusDays(days.toLong()), from.minusDays(1))
    operator fun contains(d: LocalDate): Boolean = !d.isBefore(from) && !d.isAfter(to)
}

fun List<MoneyEntry>.inSpan(p: DateSpan): List<MoneyEntry> = filter { it.dateMillis.toLocalDate() in p }

fun accountTotals(list: List<MoneyEntry>, bucket: Bucket): List<Pair<String?, Double>> =
    list.filter { it.category.bucket() == bucket }
        .groupBy { it.account }
        .map { entry -> Pair(entry.key, entry.value.sumOf { it.amount }) }
        .sortedByDescending { it.second }

fun dailyTotals(list: List<MoneyEntry>, p: DateSpan): List<Pair<LocalDate, Totals>> {
    val by = list.groupBy { it.dateMillis.toLocalDate() }
    return (0 until p.days).map { k ->
        val d = p.from.plusDays(k.toLong())
        Pair(d, totalsOf(by[d].orEmpty()))
    }
}

enum class AdviceLevel { GOOD, INFO, WARN, BAD }

sealed interface Advice {
    val level: AdviceLevel
    data class Deficit(val amount: Double) : Advice { override val level = AdviceLevel.BAD }
    data class ForecastDeficit(val amount: Double) : Advice { override val level = AdviceLevel.WARN }
    data class ForecastSurplus(val amount: Double) : Advice { override val level = AdviceLevel.GOOD }
    data class ExpenseUp(val pct: Int, val topName: String?, val topDelta: Double) : Advice { override val level = AdviceLevel.WARN }
    data class ExpenseDown(val pct: Int, val saved: Double) : Advice { override val level = AdviceLevel.GOOD }
    data class IncomeDown(val pct: Int) : Advice { override val level = AdviceLevel.WARN }
    data class IncomeUp(val pct: Int) : Advice { override val level = AdviceLevel.GOOD }
    data class SavingLow(val ratePct: Int) : Advice { override val level = AdviceLevel.WARN }
    data class SavingGood(val ratePct: Int) : Advice { override val level = AdviceLevel.GOOD }
    data class SavingUp(val pct: Int) : Advice { override val level = AdviceLevel.GOOD }
    data class SavingDown(val pct: Int) : Advice { override val level = AdviceLevel.WARN }
    data class ObligationsHeavy(val pct: Int) : Advice { override val level = AdviceLevel.WARN }
    data class ObligationsUp(val pct: Int) : Advice { override val level = AdviceLevel.WARN }
    data class TopAccount(val name: String, val pct: Int) : Advice { override val level = AdviceLevel.INFO }
    data class Overdue(val count: Int, val amount: Double) : Advice { override val level = AdviceLevel.BAD }
    data object OnTrack : Advice { override val level = AdviceLevel.GOOD }
    data object NoData : Advice { override val level = AdviceLevel.INFO }
}

data class PeriodReport(
    val range: DateSpan,
    val totals: Totals,
    val prev: Totals,
    val expenseByAccount: List<Pair<String?, Double>>,
    val obligationByAccount: List<Pair<String?, Double>>,
    val daily: List<Pair<LocalDate, Totals>>,
    val tips: List<Advice>
)

fun buildReport(
    all: List<MoneyEntry>, range: DateSpan, prevRange: DateSpan,
    bills: List<Bill>, debts: List<Debt>, today: LocalDate
): PeriodReport {
    val cur = all.inSpan(range)
    val prevList = all.inSpan(prevRange)
    val t = totalsOf(cur)
    val p = totalsOf(prevList)
    val expAcc = accountTotals(cur, Bucket.EXPENSE)
    val oblAcc = accountTotals(cur, Bucket.OBLIGATION)
    val prevExpAcc: Map<String?, Double> = accountTotals(prevList, Bucket.EXPENSE).toMap()

    val inProgress = today in range && today.isBefore(range.to)
    val elapsed = if (inProgress) ChronoUnit.DAYS.between(range.from, today).toInt() + 1 else range.days
    val progress = if (inProgress) elapsed.toDouble() / range.days else 1.0

    val tips = mutableListOf<Advice>()

    if (cur.isNotEmpty()) {
        if (t.income > 0 && t.outflow > t.income) {
            tips.add(Advice.Deficit(t.outflow - t.income))
        }

        // توقع نهاية الفترة (للفترات الجارية فقط)
        if (inProgress && range.days >= 7 && elapsed >= 3) {
            val projExpense = t.expense / elapsed * range.days
            val expectedIncome = maxOf(t.income, p.income)
            val expectedObl = maxOf(t.obligation, p.obligation)
            if (expectedIncome > 0) {
                val net = expectedIncome - (projExpense + expectedObl + t.saving)
                if (net < 0) tips.add(Advice.ForecastDeficit(-net)) else tips.add(Advice.ForecastSurplus(net))
            }
        }

        // المصروفات
        val prevExp = p.expense * progress
        if (prevExp > 0) {
            if (t.expense > prevExp * 1.2) {
                var topName: String? = null
                var topDelta = 0.0
                for (pair in expAcc) {
                    val d = pair.second - (prevExpAcc[pair.first] ?: 0.0) * progress
                    if (d > topDelta) {
                        topDelta = d
                        topName = pair.first
                    }
                }
                tips.add(Advice.ExpenseUp(((t.expense / prevExp - 1) * 100).toInt(), topName, topDelta))
            } else if (t.expense < prevExp * 0.85) {
                tips.add(Advice.ExpenseDown(((1 - t.expense / prevExp) * 100).toInt(), prevExp - t.expense))
            }
        }

        // الدخل
        if (!inProgress && p.income > 0 && t.income < p.income * 0.9) {
            tips.add(Advice.IncomeDown(((1 - t.income / p.income) * 100).toInt()))
        }
        if (p.income > 0 && t.income > p.income * 1.1) {
            tips.add(Advice.IncomeUp(((t.income / p.income - 1) * 100).toInt()))
        }

        // الادخار
        if (t.income > 0) {
            val r = (t.savingRate * 100).toInt()
            if (t.savingRate < 0.10) {
                tips.add(Advice.SavingLow(r))
            } else if (t.savingRate >= 0.20) {
                tips.add(Advice.SavingGood(r))
            }
        }
        if (!inProgress && p.saving > 0) {
            if (t.saving > p.saving * 1.1) {
                tips.add(Advice.SavingUp(((t.saving / p.saving - 1) * 100).toInt()))
            } else if (t.saving < p.saving * 0.8) {
                tips.add(Advice.SavingDown(((1 - t.saving / p.saving) * 100).toInt()))
            }
        }

        // الالتزامات
        if (t.income > 0 && t.obligation / t.income > 0.5) {
            tips.add(Advice.ObligationsHeavy((t.obligation / t.income * 100).toInt()))
        }
        if (!inProgress && p.obligation > 0 && t.obligation > p.obligation * 1.2) {
            tips.add(Advice.ObligationsUp(((t.obligation / p.obligation - 1) * 100).toInt()))
        }

        // أكبر حساب في المصروفات
        val top = expAcc.firstOrNull { it.first != null }
        if (top != null && expAcc.size > 1 && t.expense > 0 && top.second / t.expense > 0.4) {
            tips.add(Advice.TopAccount(top.first ?: "", (top.second / t.expense * 100).toInt()))
        }
    }

    // المتأخرات (للفترة التي تشمل اليوم)
    if (today in range) {
        val ob = bills.filter { !it.paid && it.dueDateMillis.toLocalDate().isBefore(today) }
        val od = debts.filter { !it.paid && !it.owedToMe && it.dueDateMillis.toLocalDate().isBefore(today) }
        val cnt = ob.size + od.size
        if (cnt > 0) tips.add(Advice.Overdue(cnt, ob.sumOf { it.amount } + od.sumOf { it.amount }))
    }

    if (tips.isEmpty()) {
        if (cur.isEmpty()) tips.add(Advice.NoData) else tips.add(Advice.OnTrack)
    }

    return PeriodReport(
        range, t, p, expAcc, oblAcc, dailyTotals(cur, range),
        tips.sortedByDescending { it.level.ordinal }
    )
}
