package com.example.finance.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.finance.R
import com.example.finance.domain.*
import java.time.LocalDate
import kotlin.math.abs

@Composable
fun DeltaText(cur: Double, prev: Double, upIsGood: Boolean) {
    if (prev <= 0.0) return
    val pct = ((cur / prev - 1) * 100).toInt()
    if (pct == 0) return
    val up = pct > 0
    val good = up == upIsGood
    Text(
        (if (up) "▲ " else "▼ ") + abs(pct) + "%",
        color = if (good) GREEN else RED,
        style = MaterialTheme.typography.labelSmall
    )
}

@Composable
fun TotalRow(@StringRes label: Int, value: Double, prev: Double?, upIsGood: Boolean, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Dot(color)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(label), Modifier.weight(1f))
        if (prev != null) {
            DeltaText(value, prev, upIsGood)
            Spacer(Modifier.width(8.dp))
        }
        Text(money(value), style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
fun TotalsCard(t: Totals, prev: Totals? = null) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TotalRow(R.string.sec_income, t.income, prev?.income, true, GREEN)
            TotalRow(R.string.sec_expenses, t.expense, prev?.expense, false, RED)
            TotalRow(R.string.sec_obl, t.obligation, prev?.obligation, false, ORANGE)
            TotalRow(R.string.sec_saving, t.saving, prev?.saving, true, BLUE)
            HorizontalDivider()
            TotalRow(R.string.net, t.net, prev?.net, true, if (t.net >= 0) GREEN else RED)
        }
    }
}

@Composable
fun BucketChart(t: Totals) {
    val vals = listOf(Pair(t.income, GREEN), Pair(t.expense, RED), Pair(t.obligation, ORANGE), Pair(t.saving, BLUE))
    val max = vals.maxOf { it.first }.coerceAtLeast(1.0)
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val w = size.width / (vals.size * 2)
        vals.forEachIndexed { i, p ->
            val h = (p.first / max).toFloat() * size.height
            drawRect(p.second, Offset(i * 2 * w + w / 2, size.height - h), Size(w, h))
        }
    }
}

@Composable
fun AccountBreakdown(list: List<Pair<String?, Double>>, total: Double) {
    if (list.isEmpty()) {
        Text(stringResource(R.string.none), style = MaterialTheme.typography.bodySmall)
        return
    }
    val noAcc = stringResource(R.string.no_account)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { p ->
            val share = if (total > 0) (p.second / total).toFloat().coerceIn(0f, 1f) else 0f
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.first ?: noAcc)
                    Text(money(p.second) + " · " + (share * 100).toInt() + "%", style = MaterialTheme.typography.labelLarge)
                }
                LinearProgressIndicator(progress = { share }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun MiniAmount(color: Color, v: Double) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Dot(color)
        Text(num(v), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DailyRow(d: LocalDate, t: Totals) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(d.toString(), style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MiniAmount(GREEN, t.income)
                MiniAmount(RED, t.expense)
                MiniAmount(ORANGE, t.obligation)
                MiniAmount(BLUE, t.saving)
            }
        }
    }
}

@Composable
fun AdviceCard(t: Advice) {
    val msg = when (t) {
        is Advice.Deficit -> stringResource(R.string.tip_deficit, money(t.amount))
        is Advice.ForecastDeficit -> stringResource(R.string.tip_forecast_deficit, money(t.amount))
        is Advice.ForecastSurplus -> stringResource(R.string.tip_forecast_surplus, money(t.amount))
        is Advice.ExpenseUp ->
            if (t.topName != null && t.topDelta > 0) stringResource(R.string.tip_expense_up_top, t.pct, t.topName, money(t.topDelta))
            else stringResource(R.string.tip_expense_up, t.pct)
        is Advice.ExpenseDown -> stringResource(R.string.tip_expense_down, t.pct, money(t.saved))
        is Advice.IncomeDown -> stringResource(R.string.tip_income_down, t.pct)
        is Advice.IncomeUp -> stringResource(R.string.tip_income_up, t.pct)
        is Advice.SavingLow -> stringResource(R.string.tip_saving_low, t.ratePct)
        is Advice.SavingGood -> stringResource(R.string.tip_saving_good, t.ratePct)
        is Advice.SavingUp -> stringResource(R.string.tip_saving_up, t.pct)
        is Advice.SavingDown -> stringResource(R.string.tip_saving_down, t.pct)
        is Advice.ObligationsHeavy -> stringResource(R.string.tip_obl_heavy, t.pct)
        is Advice.ObligationsUp -> stringResource(R.string.tip_obl_up, t.pct)
        is Advice.TopAccount -> stringResource(R.string.tip_top_account, t.name, t.pct)
        is Advice.Overdue -> stringResource(R.string.tip_overdue, t.count, money(t.amount))
        Advice.OnTrack -> stringResource(R.string.tip_on_track)
        Advice.NoData -> stringResource(R.string.tip_no_data)
    }
    val icon = when (t.level) {
        AdviceLevel.GOOD -> "✅"
        AdviceLevel.INFO -> "ℹ️"
        AdviceLevel.WARN -> "⚠️"
        AdviceLevel.BAD -> "🚨"
    }
    val color = when (t.level) {
        AdviceLevel.GOOD -> GREEN
        AdviceLevel.INFO -> BLUE
        AdviceLevel.WARN -> ORANGE
        AdviceLevel.BAD -> RED
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(icon)
            Text(msg, Modifier.weight(1f))
        }
    }
}
