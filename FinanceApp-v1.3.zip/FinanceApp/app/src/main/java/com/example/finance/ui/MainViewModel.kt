package com.example.finance.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.finance.R
import com.example.finance.data.*
import com.example.finance.domain.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.YearMonth

data class UiState(
    val month: YearMonth = YearMonth.now(),
    val all: List<MoneyEntry> = emptyList(),
    val entries: List<MoneyEntry> = emptyList(),
    val bills: List<Bill> = emptyList(),
    val debts: List<Debt> = emptyList(),
    val accounts: List<SubAccount> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val month = MutableStateFlow(YearMonth.now())

    init {
        // حسابات افتراضية تُضاف مرة واحدة، ويمكنك تعديلها وإضافة غيرها
        viewModelScope.launch {
            val prefs = app.getSharedPreferences("finance", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("accounts_seeded", false)) {
                val res = app.resources
                val variable = listOf(
                    R.string.acc_food, R.string.acc_transport, R.string.acc_health, R.string.acc_education,
                    R.string.acc_clothes, R.string.acc_comm, R.string.acc_fun, R.string.acc_gifts, R.string.acc_other
                )
                for (id in variable) dao.addAccount(SubAccount(name = res.getString(id), parent = Category.VARIABLE))
                val obligations = listOf(R.string.acc_rent, R.string.acc_utilities, R.string.acc_installment)
                for (id in obligations) dao.addAccount(SubAccount(name = res.getString(id), parent = Category.OBLIGATION))
                prefs.edit().putBoolean("accounts_seeded", true).apply()
            }
        }
    }

    val state: StateFlow<UiState> = month.flatMapLatest { m ->
        combine(dao.allEntries(), dao.allBills(), dao.allDebts(), dao.allAccounts()) { all, bills, debts, accounts ->
            UiState(m, all, all.filter { YearMonth.from(it.dateMillis.toLocalDate()) == m }, bills, debts, accounts)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    fun shift(delta: Long) { month.value = month.value.plusMonths(delta) }

    fun add(amount: Double, type: EntryType, cat: Category, note: String, dateMillis: Long, account: String?) = viewModelScope.launch {
        dao.add(MoneyEntry(amount = amount, type = type, category = cat, note = note, dateMillis = dateMillis, account = account))
    }
    fun deleteEntry(e: MoneyEntry) = viewModelScope.launch { dao.delete(e) }

    fun addAccount(name: String, parent: Category) = viewModelScope.launch {
        val n = name.trim()
        if (n.isNotEmpty() && dao.accountExists(n, parent) == 0) dao.addAccount(SubAccount(name = n, parent = parent))
    }
    fun deleteAccount(a: SubAccount) = viewModelScope.launch { dao.deleteAccount(a) }

    fun addBill(title: String, amount: Double, due: Long, repeat: Boolean, remindDays: Int, notes: String) = viewModelScope.launch {
        dao.addBill(Bill(title = title, amount = amount, dueDateMillis = due, repeatMonthly = repeat, remindDaysBefore = remindDays, notes = notes))
    }
    fun payBill(b: Bill) = viewModelScope.launch {
        dao.updateBill(b.copy(paid = true))
        dao.add(MoneyEntry(amount = b.amount, type = EntryType.EXPENSE, category = Category.OBLIGATION, note = b.title, dateMillis = System.currentTimeMillis()))
        if (b.repeatMonthly) {
            val next = b.dueDateMillis.toLocalDate().plusMonths(1).toMillis()
            dao.addBill(b.copy(id = 0, dueDateMillis = next, paid = false))
        }
    }
    fun deleteBill(b: Bill) = viewModelScope.launch { dao.deleteBill(b) }

    fun addDebt(person: String, amount: Double, due: Long, owedToMe: Boolean, note: String) = viewModelScope.launch {
        dao.addDebt(Debt(person = person, amount = amount, dueDateMillis = due, owedToMe = owedToMe, note = note))
    }
    fun settleDebt(d: Debt) = viewModelScope.launch {
        dao.updateDebt(d.copy(paid = true))
        dao.add(MoneyEntry(
            amount = d.amount,
            type = if (d.owedToMe) EntryType.INCOME else EntryType.EXPENSE,
            category = if (d.owedToMe) Category.OTHER_INCOME else Category.OBLIGATION,
            note = d.person, dateMillis = System.currentTimeMillis()))
    }
    fun deleteDebt(d: Debt) = viewModelScope.launch { dao.deleteDebt(d) }
}
